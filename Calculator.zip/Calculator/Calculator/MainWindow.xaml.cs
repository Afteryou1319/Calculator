﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                decimal income = decimal.Parse(IncomeTextBox.Text);
                decimal expense = decimal.Parse(ExpenseTextBox.Text);
                decimal goalPrice = decimal.Parse(GoalPriceTextBox.Text);

                decimal dailySavings = income - expense;

                if (dailySavings <= 0)
                {
                    ResultTextBlock.Text = "ไม่สามารถเก็บเงินได้";
                }
                else
                {
                    decimal daysRequired = Math.Ceiling(goalPrice / dailySavings);
                    ResultTextBlock.Text = $"{daysRequired}";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("กรุณากรอกข้อมูลให้ถูกต้อง", "ข้อผิดพลาด", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}